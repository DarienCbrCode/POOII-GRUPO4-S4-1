package listadejer;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GestorLibros {
    private static final String ARCHIVO_LIBROS = "libros.txt";

    public static void agregarLibro(Libro libro) throws IOException {
        List<Libro> libros = leerLibros();
        libros.add(libro);
        escribirLibros(libros);
    }

    public static List<Libro> leerLibros() throws IOException {
        File archivo = new File(ARCHIVO_LIBROS);
        if (!archivo.exists()) {
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            return (List<Libro>) ois.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    private static void escribirLibros(List<Libro> libros) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_LIBROS))) {
            oos.writeObject(libros);
        }
    }

    public static Libro buscarLibroPorISBN(String isbn) throws IOException {
        List<Libro> libros = leerLibros();
        for (Libro libro : libros) {
            if (libro.getIsbn().equals(isbn)) {
                return libro;
            }
        }
        return null;
    }
}
