package listadejer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class VentanaCrearLibro extends JFrame {
    private JTextField txtISBN;
    private JTextField txtTitulo;
    private JTextField txtAutor;
    private JButton btnGuardar;

    public VentanaCrearLibro() {
        setTitle("Crear Libro");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Definir un layout más similar a lo visto en el PDF
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Labels y campos de texto
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("ISBN:"), gbc);

        gbc.gridx = 1;
        txtISBN = new JTextField(20);
        panel.add(txtISBN, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Título:"), gbc);

        gbc.gridx = 1;
        txtTitulo = new JTextField(20);
        panel.add(txtTitulo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Autor:"), gbc);

        gbc.gridx = 1;
        txtAutor = new JTextField(20);
        panel.add(txtAutor, gbc);

        // Botón de Guardar
        btnGuardar = new JButton("Guardar");
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(btnGuardar, gbc);

        add(panel);
        setVisible(true);

        // Acción para guardar el libro
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String isbn = txtISBN.getText();
                String titulo = txtTitulo.getText();
                String autor = txtAutor.getText();
                if (!isbn.isEmpty() && !titulo.isEmpty() && !autor.isEmpty()) {
                    try {
                        GestorLibros.agregarLibro(new Libro(isbn, titulo, autor));
                        JOptionPane.showMessageDialog(null, "Libro guardado exitosamente!");
                        dispose();
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error al guardar el libro.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
                }
            }
        });
    }
}
