package listadejer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame {
    private JButton btnCrearLibro;
    private JButton btnBuscarLibro;

    public VentanaPrincipal() {
        setTitle("Gestión de Libros");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20);
        
        btnCrearLibro = new JButton("Crear Libro");
        btnBuscarLibro = new JButton("Buscar Libro");

        // Agregar botones con espaciado adecuado
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(btnCrearLibro, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(btnBuscarLibro, gbc);

        add(panel);

        // Acción para el botón "Crear Libro"
        btnCrearLibro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new VentanaCrearLibro();
            }
        });

        // Acción para el botón "Buscar Libro"
        btnBuscarLibro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new VentanaBuscarLibro();
            }
        });

        setVisible(true);
    }
}
