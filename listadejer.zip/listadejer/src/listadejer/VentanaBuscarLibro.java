package listadejer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class VentanaBuscarLibro extends JFrame {
    private JTextField txtISBN;
    private JButton btnBuscar;
    private JTextArea areaResultado;

    public VentanaBuscarLibro() {
        setTitle("Buscar Libro");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel("Ingrese ISBN:"), gbc);

        gbc.gridx = 1;
        txtISBN = new JTextField(20);
        panel.add(txtISBN, gbc);

        // Botón de buscar
        gbc.gridx = 1;
        gbc.gridy = 1;
        btnBuscar = new JButton("Buscar");
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(btnBuscar, gbc);

        // Área de resultado
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        areaResultado = new JTextArea(8, 30);
        areaResultado.setEditable(false);
        panel.add(new JScrollPane(areaResultado), gbc);

        add(panel);
        setVisible(true);

        // Acción para buscar el libro
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String isbn = txtISBN.getText();
                if (!isbn.isEmpty()) {
                    try {
                        Libro libro = GestorLibros.buscarLibroPorISBN(isbn);
                        if (libro != null) {
                            areaResultado.setText(libro.toString());
                        } else {
                            areaResultado.setText("No se encontró ningún libro con ese ISBN.");
                        }
                    } catch (IOException ex) {
                        areaResultado.setText("Error al buscar el libro.");
                    }
                } else {
                    areaResultado.setText("Debe ingresar un ISBN.");
                }
            }
        });
    }
}
