package listadejer;

public class Listadejer {
    public static void main(String[] args) {
        // Crear instancia de la ventana principal para iniciar la aplicación
        VentanaPrincipal ventana = new VentanaPrincipal();
        ventana.setVisible(true);
        System.out.println("Programa ejecutado correctamente.");
    }
}
