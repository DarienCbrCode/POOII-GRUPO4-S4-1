package Ejercicio1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

public class Interfaz extends javax.swing.JFrame {

    public Interfaz() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        ISBN = new javax.swing.JTextField();
        Titulo = new javax.swing.JTextField();
        jComboBoxAutor = new javax.swing.JComboBox<>();
        btnNuevoAutor = new javax.swing.JButton();
        Sinopsis = new javax.swing.JTextField();
        btnTerror = new javax.swing.JRadioButton();
        btnCienciaFiccion = new javax.swing.JRadioButton();
        btnRomance = new javax.swing.JRadioButton();
        btnFantasia = new javax.swing.JRadioButton();
        jCheckBoxLeido = new javax.swing.JCheckBox();
        jCheckBoxLoTengo = new javax.swing.JCheckBox();
        btnCancelar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("ISBN:");

        jLabel2.setText("Titulo:");

        jLabel3.setText("Autor:");

        jLabel4.setText("Sipnosis:");

        jLabel5.setText("Genero");

        ISBN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ISBNActionPerformed(evt);
            }
        });

        Titulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TituloActionPerformed(evt);
            }
        });

        jComboBoxAutor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mario Vargas Llosa", "Cesar Vallejo", "Ricardo Palma", "Ciro alegria", "Rafael Dummet", "Jorge amado", "Paulo Coelho", "Daniel Galera", "Henry James", "Gabriel Garcia Marquez", " ", " " }));
        jComboBoxAutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxAutorActionPerformed(evt);
            }
        });

        btnNuevoAutor.setText("Nuevo Autor");
        btnNuevoAutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoAutorActionPerformed(evt);
            }
        });

        Sinopsis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SinopsisActionPerformed(evt);
            }
        });

        btnTerror.setText("Terror");
        btnTerror.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTerrorActionPerformed(evt);
            }
        });

        btnCienciaFiccion.setText("Ciencia Ficción");
        btnCienciaFiccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCienciaFiccionActionPerformed(evt);
            }
        });

        btnRomance.setText("Romance");
        btnRomance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRomanceActionPerformed(evt);
            }
        });

        btnFantasia.setText("Fantasia");
        btnFantasia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFantasiaActionPerformed(evt);
            }
        });

        jCheckBoxLeido.setText("Leido");
        jCheckBoxLeido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxLeidoActionPerformed(evt);
            }
        });

        jCheckBoxLoTengo.setText("Lo tengo");
        jCheckBoxLoTengo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxLoTengoActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBoxAutor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Titulo)
                            .addComponent(ISBN)
                            .addComponent(Sinopsis)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnCienciaFiccion)
                                .addGap(18, 18, 18)
                                .addComponent(btnFantasia)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 152, Short.MAX_VALUE)
                                .addComponent(jCheckBoxLeido)
                                .addGap(32, 32, 32)
                                .addComponent(jCheckBoxLoTengo)
                                .addGap(47, 47, 47))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnTerror)
                                .addGap(64, 64, 64)
                                .addComponent(btnRomance)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(54, 54, 54)
                        .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(226, 226, 226)
                .addComponent(btnNuevoAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ISBN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBoxAutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addComponent(btnNuevoAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Sinopsis, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(btnTerror)
                    .addComponent(btnRomance))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBoxLeido)
                    .addComponent(jCheckBoxLoTengo)
                    .addComponent(btnCienciaFiccion)
                    .addComponent(btnFantasia))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 5, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ISBNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ISBNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ISBNActionPerformed

    private void TituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TituloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TituloActionPerformed

    private void jComboBoxAutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxAutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxAutorActionPerformed

    private void btnNuevoAutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoAutorActionPerformed
     // Crear y mostrar el diálogo para agregar un nuevo autor
    VentanaEmergenteAutor ventanaNuevoAutor = new VentanaEmergenteAutor(this, jComboBoxAutor);
    ventanaNuevoAutor.setVisible(true);                                
    }//GEN-LAST:event_btnNuevoAutorActionPerformed

    private void SinopsisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SinopsisActionPerformed
     
    }//GEN-LAST:event_SinopsisActionPerformed

    private void btnTerrorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTerrorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTerrorActionPerformed

    private void btnRomanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRomanceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnRomanceActionPerformed

    private void btnCienciaFiccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCienciaFiccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCienciaFiccionActionPerformed

    private void btnFantasiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFantasiaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFantasiaActionPerformed

    private void jCheckBoxLeidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxLeidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxLeidoActionPerformed

    private void jCheckBoxLoTengoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxLoTengoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxLoTengoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
            // Obtener los valores ingresados
        String isbn = ISBN.getText();
        String titulo = Titulo.getText();
        String autor = (String) jComboBoxAutor.getSelectedItem();
        String sinopsis = Sinopsis.getText();
        
        // Determinar el género seleccionado
        String genero = "";
        if (btnTerror.isSelected()) {
            genero = "Terror";
        } else if (btnCienciaFiccion.isSelected()) {
            genero = "Ciencia Ficción";
        } else if (btnRomance.isSelected()) {
            genero = "Romance";
        } else if (btnFantasia.isSelected()) {
            genero = "Fantasía";
        }

        // Determinar si el libro ha sido leído o si lo tienes
        boolean leido = jCheckBoxLeido.isSelected();
        boolean loTengo = jCheckBoxLoTengo.isSelected();

        // Guardar la información en un archivo
        guardarLibro(isbn, titulo, autor, sinopsis, genero, leido, loTengo);
    }//GEN-LAST:event_btnGuardarActionPerformed
    private void guardarLibro(String isbn, String titulo, String autor, String sinopsis, String genero, boolean leido, boolean loTengo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("libros.txt", true))) {
            writer.write(isbn + "," + titulo + "," + autor + "," + sinopsis + "," + genero + "," + leido + "," + loTengo);
            writer.newLine();
            JOptionPane.showMessageDialog(this, "Libro guardado correctamente");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar el libro");
        }
    }
    
    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCancelarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ISBN;
    private javax.swing.JTextField Sinopsis;
    private javax.swing.JTextField Titulo;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JRadioButton btnCienciaFiccion;
    private javax.swing.JRadioButton btnFantasia;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevoAutor;
    private javax.swing.JRadioButton btnRomance;
    private javax.swing.JRadioButton btnTerror;
    private javax.swing.JCheckBox jCheckBoxLeido;
    private javax.swing.JCheckBox jCheckBoxLoTengo;
    private javax.swing.JComboBox<String> jComboBoxAutor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
