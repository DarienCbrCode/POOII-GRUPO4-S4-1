package Ejercicio1;

import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class VentanaEmergenteAutor extends JDialog {
    private JTextField campoNombre;
    private JButton btnGuardar;
    private JComboBox<String> comboBoxAutor;

    public VentanaEmergenteAutor(JFrame parent, JComboBox<String> comboBoxAutor) {
        super(parent, "Nuevo Autor", true);
        this.comboBoxAutor = comboBoxAutor;

        // Configuración del diálogo
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Campo para ingresar el nombre del autor
        campoNombre = new JTextField(20);
        add(new JLabel("Nombre del autor:"));
        add(campoNombre);

        // Botón para guardar el autor
        btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(e -> guardarAutor());
        add(btnGuardar);

        pack();
        setLocationRelativeTo(parent);
    }

    private void guardarAutor() {
        String nombreAutor = campoNombre.getText().trim();

        if (!nombreAutor.isEmpty()) {
            // Guardar el autor en el archivo
            try (BufferedWriter bw = new BufferedWriter(new FileWriter("Autores.txt", true))) {
                bw.write(nombreAutor);
                bw.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Actualizar el JComboBox en la interfaz principal
            comboBoxAutor.addItem(nombreAutor);
            
            // Cerrar el diálogo
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
